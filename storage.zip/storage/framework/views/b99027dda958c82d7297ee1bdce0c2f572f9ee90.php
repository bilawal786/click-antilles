<?php $__env->startSection('title',$product['name']); ?>

<?php $__env->startPush('css_or_js'); ?>
    <meta name="description" content="<?php echo e($product->slug); ?>">
    <meta name="keywords" content="<?php $__currentLoopData = explode(' ',$product['name']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($keyword.' , '); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">
    <?php if($product->added_by=='seller'): ?>
        <meta name="author" content="<?php echo e($product->seller->shop?$product->seller->shop->name:$product->seller->f_name); ?>">
    <?php elseif($product->added_by=='admin'): ?>
        <meta name="author" content="<?php echo e($web_config['name']->value); ?>">
    <?php endif; ?>
    <!-- Viewport-->

    <?php if($product['meta_image']!=null): ?>
        <meta property="og:image" content="<?php echo e(asset("storage/app/public/product/meta")); ?>/<?php echo e($product->meta_image); ?>"/>
        <meta property="twitter:card"
              content="<?php echo e(asset("storage/app/public/product/meta")); ?>/<?php echo e($product->meta_image); ?>"/>
    <?php else: ?>
        <meta property="og:image" content="<?php echo e(asset("storage/app/public/product/thumbnail")); ?>/<?php echo e($product->thumbnail); ?>"/>
        <meta property="twitter:card"
              content="<?php echo e(asset("storage/app/public/product/thumbnail/")); ?>/<?php echo e($product->thumbnail); ?>"/>
    <?php endif; ?>

    <?php if($product['meta_title']!=null): ?>
        <meta property="og:title" content="<?php echo e($product->meta_title); ?>"/>
        <meta property="twitter:title" content="<?php echo e($product->meta_title); ?>"/>
    <?php else: ?>
        <meta property="og:title" content="<?php echo e($product->name); ?>"/>
        <meta property="twitter:title" content="<?php echo e($product->name); ?>"/>
    <?php endif; ?>
    <meta property="og:url" content="<?php echo e(route('product',[$product->slug])); ?>">

    <?php if($product['meta_description']!=null): ?>
        <meta property="twitter:description" content="<?php echo $product['meta_description']; ?>">
        <meta property="og:description" content="<?php echo $product['meta_description']; ?>">
    <?php else: ?>
        <meta property="og:description"
              content="<?php $__currentLoopData = explode(' ',$product['name']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($keyword.' , '); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">
        <meta property="twitter:description"
              content="<?php $__currentLoopData = explode(' ',$product['name']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($keyword.' , '); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">
    <?php endif; ?>
    <meta property="twitter:url" content="<?php echo e(route('product',[$product->slug])); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('public/assets/front-end/css/product-details.css')); ?>"/>
    <style>
        .msg-option {
            display: none;
        }

        .chatInputBox {
            width: 100%;
        }

        .go-to-chatbox {
            width: 100%;
            text-align: center;
            padding: 5px 0px;
            display: none;
        }

        .feature_header {
            display: flex;
            justify-content: center;
        }

        .btn-number:hover {
            color: <?php echo e($web_config['secondary_color']); ?>;

        }

        .for-total-price {
            margin- <?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>: -30%;
        }

        .feature_header span {
            padding- <?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>: 15px;
            font-weight: 700;
            font-size: 25px;
            background-color: #ffffff;
            text-transform: uppercase;
        }

        .flash-deals-background-image{
            background: <?php echo e($web_config['primary_color']); ?>10;
            border-radius:5px;
            width:125px;
            height:125px;
        }

        @media (max-width: 768px) {
            .feature_header span {
                margin-bottom: -40px;
            }

            .for-total-price {
                padding- <?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>: 30%;
            }

            .product-quantity {
                padding- <?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>: 4%;
            }

            .for-margin-bnt-mobile {
                margin- <?php echo e(Session::get('direction') === "rtl" ? 'left' : 'right'); ?>: 7px;
            }

            .font-for-tab {
                font-size: 11px !important;
            }

            .pro {
                font-size: 13px;
            }
        }

        @media (max-width: 375px) {
            .for-margin-bnt-mobile {
                margin- <?php echo e(Session::get('direction') === "rtl" ? 'left' : 'right'); ?>: 3px;
            }

            .for-discount {
                margin- <?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>: 10% !important;
            }

            .for-dicount-div {
                margin-top: -5%;
                margin- <?php echo e(Session::get('direction') === "rtl" ? 'left' : 'right'); ?>: -7%;
            }

            .product-quantity {
                margin- <?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>: 4%;
            }

        }

        @media (max-width: 500px) {
            .for-dicount-div {
                margin-top: -4%;
                margin- <?php echo e(Session::get('direction') === "rtl" ? 'left' : 'right'); ?>: -5%;
            }

            .for-total-price {
                margin- <?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>: -20%;
            }

            .view-btn-div {

                margin-top: -9%;
                float: <?php echo e(Session::get('direction') === "rtl" ? 'left' : 'right'); ?>;
            }

            .for-discount {
                margin- <?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>: 7%;
            }

            .viw-btn-a {
                font-size: 10px;
                font-weight: 600;
            }

            .feature_header span {
                margin-bottom: -7px;
            }

            .for-mobile-capacity {
                margin- <?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>: 7%;
            }
        }
    </style>
    <style>
        th, td {
            border-bottom: 1px solid #ddd;
            padding: 5px;
        }

        thead {
            background: <?php echo e($web_config['primary_color']); ?> !important;
            color: white;
        }
        .product-details-shipping-details{
            background: #ffffff;
            border-radius: 5px;
            font-size: 14;
            font-weight: 400;
            color: #212629;
        }
        .shipping-details-bottom-border{
            border-bottom: 1px #F9F9F9 solid;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php
    $overallRating = \App\CPU\ProductManager::get_overall_rating($product->reviews);
    $rating = \App\CPU\ProductManager::get_rating($product->reviews);
    ?>
    <!-- Page Content-->
    <div class="container mt-4 rtl" style="text-align: <?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>;">
        <!-- General info tab-->
        <div class="row" style="direction: ltr">
            <!-- Product gallery-->
            <div class="col-md-9 col-12">
                <div class="row">
                    <div class="col-lg-5 col-md-4 col-12">
                        <div class="cz-product-gallery">
                            <div class="cz-preview">
                                <?php if($product->images!=null): ?>
                                    <?php $__currentLoopData = json_decode($product->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div
                                            class="cz-preview-item d-flex align-items-center justify-content-center <?php echo e($key==0?'active':''); ?>"
                                            id="image<?php echo e($key); ?>">
                                            <img class="cz-image-zoom img-responsive" style="width:100%;height:auto"
                                                onerror="this.src='<?php echo e(asset('public/assets/front-end/img/image-place-holder.png')); ?>'"
                                                src="<?php echo e(asset("storage/app/public/product/$photo")); ?>"
                                                data-zoom="<?php echo e(asset("storage/app/public/product/$photo")); ?>"
                                                alt="Product image" width="">
                                            <div class="cz-image-zoom-pane"></div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                            <div class="cz">
                                <div>
                                    <div class="row">
                                        <div class="table-responsive" data-simplebar style="max-height: 515px; padding: 1px;">
                                            <div class="d-flex" style="padding-left: 3px;">
                                                <?php if($product->images!=null): ?>
                                                    <?php $__currentLoopData = json_decode($product->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="cz-thumblist">
                                                            <a class="cz-thumblist-item  <?php echo e($key==0?'active':''); ?> d-flex align-items-center justify-content-center "
                                                            href="#image<?php echo e($key); ?>">
                                                                <img
                                                                    onerror="this.src='<?php echo e(asset('public/assets/front-end/img/image-place-holder.png')); ?>'"
                                                                    src="<?php echo e(asset("storage/app/public/product/$photo")); ?>"
                                                                    alt="Product thumb">
                                                            </a>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Product details-->
                    <div class="col-lg-7 col-md-8 col-12 mt-md-0 mt-sm-3" style="direction: <?php echo e(Session::get('direction')); ?>">
                        <div class="details">
                            <span class="mb-2" style="font-size: 22px;font-weight:700;"><?php echo e($product->name); ?></span>
                            <div class="d-flex align-items-center mb-2 pro">
                                <span
                                    class="d-inline-block  align-middle mt-1 <?php echo e(Session::get('direction') === "rtl" ? 'ml-md-2 ml-sm-0 pl-2' : 'mr-md-2 mr-sm-0 pr-2'); ?>"
                                    style="color: #FE961C"><?php echo e($overallRating[0]); ?></span>
                                <div class="star-rating" style="<?php echo e(Session::get('direction') === "rtl" ? 'margin-left: 25px;' : 'margin-right: 25px;'); ?>">
                                    <?php for($inc=0;$inc<5;$inc++): ?>
                                        <?php if($inc<$overallRating[0]): ?>
                                            <i class="sr-star czi-star-filled active"></i>
                                        <?php else: ?>
                                            <i class="sr-star czi-star"></i>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                </div>
                                <span style="font-weight: 400;"
                                    class="font-for-tab d-inline-block font-size-sm text-body align-middle mt-1 <?php echo e(Session::get('direction') === "rtl" ? 'mr-1 ml-md-2 ml-1 pr-md-2 pr-sm-1 pl-md-2 pl-sm-1' : 'ml-1 mr-md-2 mr-1 pl-md-2 pl-sm-1 pr-md-2 pr-sm-1'); ?>"><?php echo e($overallRating[1]); ?> <?php echo e(\App\CPU\translate('Reviews')); ?></span>







                            </div>
                            <div class="mb-3">
                                <?php if($product->discount > 0): ?>
                                    <strike style="color: #E96A6A;" class="<?php echo e(Session::get('direction') === "rtl" ? 'ml-1' : 'mr-3'); ?>">
                                        <?php echo e(\App\CPU\Helpers::currency_converter($product->unit_price)); ?>

                                    </strike>
                                <?php endif; ?>
                                <span
                                    class="h3 font-weight-normal text-accent ">
                                    <?php echo e(\App\CPU\Helpers::get_price_range($product)); ?>

                                </span>





                            </div>



                            <form id="add-to-cart-form" class="mb-2">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                <div class="position-relative <?php echo e(Session::get('direction') === "rtl" ? 'ml-n4' : 'mr-n4'); ?> mb-2">
                                    <?php if(count(json_decode($product->colors)) > 0): ?>
                                        <div class="flex-start">
                                            <div class="product-description-label mt-2 text-body"><?php echo e(\App\CPU\translate('color')); ?>:
                                            </div>
                                            <div>
                                                <ul class="list-inline checkbox-color mb-1 flex-start <?php echo e(Session::get('direction') === "rtl" ? 'mr-2' : 'ml-2'); ?>"
                                                    style="padding-<?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>: 0;">
                                                    <?php $__currentLoopData = json_decode($product->colors); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div>
                                                            <li>
                                                                <input type="radio"
                                                                    id="<?php echo e($product->id); ?>-color-<?php echo e($key); ?>"
                                                                    name="color" value="<?php echo e($color); ?>"
                                                                    <?php if($key == 0): ?> checked <?php endif; ?>>
                                                                <label style="background: <?php echo e($color); ?>;"
                                                                    for="<?php echo e($product->id); ?>-color-<?php echo e($key); ?>"
                                                                    data-toggle="tooltip"></label>
                                                            </li>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php
                                        $qty = 0;
                                        if(!empty($product->variation)){
                                        foreach (json_decode($product->variation) as $key => $variation) {
                                                $qty += $variation->qty;
                                            }
                                        }
                                    ?>
                                </div>
                                <?php $__currentLoopData = json_decode($product->choice_options); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row flex-start mx-0">
                                        <div
                                            class="product-description-label text-body mt-2 <?php echo e(Session::get('direction') === "rtl" ? 'pl-2' : 'pr-2'); ?>"><?php echo e($choice->title); ?>

                                            :
                                        </div>
                                        <div>
                                            <ul class="list-inline checkbox-alphanumeric checkbox-alphanumeric--style-1 mb-2 mx-1 flex-start row"
                                                style="padding-<?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>: 0;">
                                                <?php $__currentLoopData = $choice->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div>
                                                        <li class="for-mobile-capacity">
                                                            <input type="radio"
                                                                id="<?php echo e($choice->name); ?>-<?php echo e($option); ?>"
                                                                name="<?php echo e($choice->name); ?>" value="<?php echo e($option); ?>"
                                                                <?php if($key == 0): ?> checked <?php endif; ?> >
                                                            <label style="font-size: 12px;"
                                                                for="<?php echo e($choice->name); ?>-<?php echo e($option); ?>"><?php echo e($option); ?></label>
                                                        </li>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <!-- Quantity + Add to cart -->
                                <div class="row no-gutters">
                                    <div>
                                        <div class="product-description-label text-body" style="margin-top: 10px;"><?php echo e(\App\CPU\translate('Quantity')); ?>:</div>
                                    </div>
                                    <div >
                                        <div class="product-quantity d-flex justify-content-between align-items-center">
                                            <div
                                                class="d-flex justify-content-center align-items-center"
                                                style="width: 160px;color: <?php echo e($web_config['primary_color']); ?>">
                                                <span class="input-group-btn" style="">
                                                    <button class="btn btn-number" type="button"
                                                            data-type="minus" data-field="quantity"
                                                            disabled="disabled" style="padding: 10px;color: <?php echo e($web_config['primary_color']); ?>">
                                                        -
                                                    </button>
                                                </span>
                                                <input type="text" name="quantity"
                                                    class="form-control input-number text-center cart-qty-field"
                                                    placeholder="1" value="1" min="1" max="100"
                                                    style="padding: 0px !important;width: 40%;height: 25px;">
                                                <span class="input-group-btn">
                                                    <button class="btn btn-number" type="button" data-type="plus"
                                                            data-field="quantity" style="padding: 10px;color: <?php echo e($web_config['primary_color']); ?>">
                                                    +
                                                    </button>
                                                </span>
                                            </div>
                                            <div class="float-right"  id="chosen_price_div">
                                                <div class="d-flex justify-content-center align-items-center <?php echo e(Session::get('direction') === "rtl" ? 'ml-2' : 'mr-2'); ?>">
                                                    <div class="product-description-label"><strong><?php echo e(\App\CPU\translate('total_price')); ?></strong> : </div>
                                                    <strong id="chosen_price"></strong>
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                </div>

                                <div class="row flex-start no-gutters d-none mt-2">


                                    <div class="col-12">
                                        <?php if($product['current_stock']<=0): ?>
                                            <h5 class="mt-3 text-body" style="color: red"><?php echo e(\App\CPU\translate('out_of_stock')); ?></h5>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-start mt-2 mb-3">
                                    <button
                                        class="btn element-center btn-gap-<?php echo e(Session::get('direction') === "rtl" ? 'left' : 'right'); ?>"
                                        onclick="buy_now()"
                                        type="button"
                                        style="width:37%; height: 45px; background: #FFA825 !important; color: #ffffff;">
                                        <span class="string-limit"><?php echo e(\App\CPU\translate('buy_now')); ?></span>
                                    </button>
                                    <button
                                        class="btn btn-primary element-center btn-gap-<?php echo e(Session::get('direction') === "rtl" ? 'left' : 'right'); ?>"
                                        onclick="addToCart()"
                                        type="button"
                                        style="width:37%; height: 45px;<?php echo e(Session::get('direction') === "rtl" ? 'margin-right: 20px;' : 'margin-left: 20px;'); ?>">
                                        <span class="string-limit"><?php echo e(\App\CPU\translate('add_to_cart')); ?></span>
                                    </button>
                                    <button type="button" onclick="addWishlist('<?php echo e($product['id']); ?>')"
                                            class="btn for-hover-bg"
                                            style="color:<?php echo e($web_config['secondary_color']); ?>;font-size: 18px;">
                                        <i class="fa fa-heart-o "
                                        aria-hidden="true"></i>
                                        <span class="countWishlist-<?php echo e($product['id']); ?>"><?php echo e($countWishlist); ?></span>
                                    </button>
                                </div>
                            </form>



                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="mt-4 rtl col-12" style="text-align: <?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>;">
                        <div class="row" >
                            <div class="col-12">
                                <div class=" mt-1">
                                    <!-- Tabs-->
                                    <ul class="nav nav-tabs d-flex justify-content-center" role="tablist" style="margin-top:35px;">
                                        <li class="nav-item">
                                            <a class="nav-link active " href="#overview" data-toggle="tab" role="tab"
                                            style="color: black !important;font-weight: 400;font-size: 24px;">
                                                <?php echo e(\App\CPU\translate('overview')); ?>

                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#reviews" data-toggle="tab" role="tab"
                                            style="color: black !important;font-weight: 400;font-size: 24px;">
                                                <?php echo e(\App\CPU\translate('reviews')); ?>

                                            </a>
                                        </li>
                                    </ul>
                                    <div class="px-4 pt-lg-3 pb-3 mb-3 mr-0 mr-md-2" style="background: #ffffff;border-radius:10px;min-height: 817px;">
                                        <div class="tab-content px-lg-3">
                                            <!-- Tech specs tab-->
                                            <div class="tab-pane fade show active" id="overview" role="tabpanel">
                                                <div class="row pt-2 specification">
                                                    <?php if($product->video_url!=null): ?>
                                                        <div class="col-12 mb-4">
                                                            <iframe width="420" height="315"
                                                                    src="<?php echo e($product->video_url); ?>">
                                                            </iframe>
                                                        </div>
                                                    <?php endif; ?>

                                                    <div class="text-body col-lg-12 col-md-12" style="overflow: scroll;">
                                                        <?php echo $product['details']; ?>

                                                    </div>
                                                </div>
                                            </div>
                                            <?php ($reviews_of_product = App\Model\Review::where('product_id',$product->id)->paginate(2)); ?>
                                            <!-- Reviews tab-->
                                            <div class="tab-pane fade" id="reviews" role="tabpanel">
                                                <div class="row pt-2 pb-3">
                                                    <div class="col-lg-4 col-md-5 ">
                                                        <div class=" row d-flex justify-content-center align-items-center">
                                                            <div class="col-12 d-flex justify-content-center align-items-center">
                                                                <h2 class="overall_review mb-2" style="font-weight: 500;font-size: 50px;">
                                                                    <?php echo e($overallRating[1]); ?>

                                                                </h2>
                                                            </div>
                                                            <div
                                                                class="d-flex justify-content-center align-items-center star-rating ">
                                                                <?php if(round($overallRating[0])==5): ?>
                                                                    <?php for($i = 0; $i < 5; $i++): ?>
                                                                        <i class="czi-star-filled font-size-sm text-accent <?php echo e(Session::get('direction') === "rtl" ? 'ml-1' : 'mr-1'); ?>"></i>
                                                                    <?php endfor; ?>
                                                                <?php endif; ?>
                                                                <?php if(round($overallRating[0])==4): ?>
                                                                    <?php for($i = 0; $i < 4; $i++): ?>
                                                                        <i class="czi-star-filled font-size-sm text-accent <?php echo e(Session::get('direction') === "rtl" ? 'ml-1' : 'mr-1'); ?>"></i>
                                                                    <?php endfor; ?>
                                                                    <i class="czi-star font-size-sm text-muted <?php echo e(Session::get('direction') === "rtl" ? 'ml-1' : 'mr-1'); ?>"></i>
                                                                <?php endif; ?>
                                                                <?php if(round($overallRating[0])==3): ?>
                                                                    <?php for($i = 0; $i < 3; $i++): ?>
                                                                        <i class="czi-star-filled font-size-sm text-accent <?php echo e(Session::get('direction') === "rtl" ? 'ml-1' : 'mr-1'); ?>"></i>
                                                                    <?php endfor; ?>
                                                                    <?php for($j = 0; $j < 2; $j++): ?>
                                                                        <i class="czi-star font-size-sm text-accent <?php echo e(Session::get('direction') === "rtl" ? 'ml-1' : 'mr-1'); ?>"></i>
                                                                    <?php endfor; ?>
                                                                <?php endif; ?>
                                                                <?php if(round($overallRating[0])==2): ?>
                                                                    <?php for($i = 0; $i < 2; $i++): ?>
                                                                        <i class="czi-star-filled font-size-sm text-accent <?php echo e(Session::get('direction') === "rtl" ? 'ml-1' : 'mr-1'); ?>"></i>
                                                                    <?php endfor; ?>
                                                                    <?php for($j = 0; $j < 3; $j++): ?>
                                                                        <i class="czi-star font-size-sm text-accent <?php echo e(Session::get('direction') === "rtl" ? 'ml-1' : 'mr-1'); ?>"></i>
                                                                    <?php endfor; ?>
                                                                <?php endif; ?>
                                                                <?php if(round($overallRating[0])==1): ?>
                                                                    <?php for($i = 0; $i < 4; $i++): ?>
                                                                        <i class="czi-star font-size-sm text-accent <?php echo e(Session::get('direction') === "rtl" ? 'ml-1' : 'mr-1'); ?>"></i>
                                                                    <?php endfor; ?>
                                                                    <i class="czi-star-filled font-size-sm text-accent <?php echo e(Session::get('direction') === "rtl" ? 'ml-1' : 'mr-1'); ?>"></i>
                                                                <?php endif; ?>
                                                                <?php if(round($overallRating[0])==0): ?>
                                                                    <?php for($i = 0; $i < 5; $i++): ?>
                                                                        <i class="czi-star font-size-sm text-muted <?php echo e(Session::get('direction') === "rtl" ? 'ml-1' : 'mr-1'); ?>"></i>
                                                                    <?php endfor; ?>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="col-12 d-flex justify-content-center align-items-center mt-2">
                                                                <span class="text-center">
                                                                    <?php echo e($reviews_of_product->total()); ?> <?php echo e(\App\CPU\translate('ratings')); ?>

                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-8 col-md-7 pt-sm-3 pt-md-0" >
                                                        <div class="row d-flex align-items-center mb-2 font-size-sm">
                                                            <div
                                                                class="col-3 text-nowrap "><span
                                                                    class="d-inline-block align-middle text-body"><?php echo e(\App\CPU\translate('Excellent')); ?></span>
                                                            </div>
                                                            <div class="col-8">
                                                                <div class="progress text-body" style="height: 5px;">
                                                                    <div class="progress-bar " role="progressbar"
                                                                        style="background-color: <?php echo e($web_config['primary_color']); ?> !important;width: <?php echo $widthRating = ($rating[0] != 0) ? ($rating[0] / $overallRating[1]) * 100 : (0); ?>%;"
                                                                        aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                                                                </div>
                                                            </div>
                                                            <div class="col-1 text-body">
                                                                <span
                                                                    class=" <?php echo e(Session::get('direction') === "rtl" ? 'mr-3 float-left' : 'ml-3 float-right'); ?> ">
                                                                    <?php echo e($rating[0]); ?>

                                                                </span>
                                                            </div>
                                                        </div>

                                                        <div class="row d-flex align-items-center mb-2 text-body font-size-sm">
                                                            <div
                                                                class="col-3 text-nowrap "><span
                                                                    class="d-inline-block align-middle "><?php echo e(\App\CPU\translate('Good')); ?></span>
                                                            </div>
                                                            <div class="col-8">
                                                                <div class="progress" style="height: 5px;">
                                                                    <div class="progress-bar" role="progressbar"
                                                                        style="background-color: <?php echo e($web_config['primary_color']); ?> !important;width: <?php echo $widthRating = ($rating[1] != 0) ? ($rating[1] / $overallRating[1]) * 100 : (0); ?>%; background-color: #a7e453;"
                                                                        aria-valuenow="27" aria-valuemin="0" aria-valuemax="100"></div>
                                                                </div>
                                                            </div>
                                                            <div class="col-1">
                                                                <span
                                                                    class="<?php echo e(Session::get('direction') === "rtl" ? 'mr-3 float-left' : 'ml-3 float-right'); ?>">
                                                                        <?php echo e($rating[1]); ?>

                                                                </span>
                                                            </div>
                                                        </div>

                                                        <div class="row d-flex align-items-center mb-2 text-body font-size-sm">
                                                            <div
                                                                class="col-3 text-nowrap"><span
                                                                    class="d-inline-block align-middle "><?php echo e(\App\CPU\translate('Average')); ?></span>
                                                            </div>
                                                            <div class="col-8">
                                                                <div class="progress" style="height: 5px;">
                                                                    <div class="progress-bar" role="progressbar"
                                                                        style="background-color: <?php echo e($web_config['primary_color']); ?> !important;width: <?php echo $widthRating = ($rating[2] != 0) ? ($rating[2] / $overallRating[1]) * 100 : (0); ?>%; background-color: #ffda75;"
                                                                        aria-valuenow="17" aria-valuemin="0" aria-valuemax="100"></div>
                                                                </div>
                                                            </div>
                                                            <div class="col-1">
                                                                <span
                                                                    class="<?php echo e(Session::get('direction') === "rtl" ? 'mr-3 float-left' : 'ml-3 float-right'); ?>">
                                                                    <?php echo e($rating[2]); ?>

                                                                </span>
                                                            </div>
                                                        </div>

                                                        <div class="row d-flex align-items-center mb-2 text-body font-size-sm">
                                                            <div
                                                                class="col-3 text-nowrap "><span
                                                                    class="d-inline-block align-middle"><?php echo e(\App\CPU\translate('Below Average')); ?></span>
                                                            </div>
                                                            <div class="col-8">
                                                                <div class="progress" style="height: 5px;">
                                                                    <div class="progress-bar" role="progressbar"
                                                                        style="background-color: <?php echo e($web_config['primary_color']); ?> !important;width: <?php echo $widthRating = ($rating[3] != 0) ? ($rating[3] / $overallRating[1]) * 100 : (0); ?>%; background-color: #fea569;"
                                                                        aria-valuenow="9" aria-valuemin="0" aria-valuemax="100"></div>
                                                                </div>
                                                            </div>
                                                            <div class="col-1">
                                                                <span
                                                                        class="<?php echo e(Session::get('direction') === "rtl" ? 'mr-3 float-left' : 'ml-3 float-right'); ?>">
                                                                    <?php echo e($rating[3]); ?>

                                                                </span>
                                                            </div>
                                                        </div>

                                                        <div class="row d-flex align-items-center text-body font-size-sm">
                                                            <div
                                                                class="col-3 text-nowrap"><span
                                                                    class="d-inline-block align-middle "><?php echo e(\App\CPU\translate('Poor')); ?></span>
                                                            </div>
                                                            <div class="col-8">
                                                                <div class="progress" style="height: 5px;">
                                                                    <div class="progress-bar" role="progressbar"
                                                                        style="background-color: <?php echo e($web_config['primary_color']); ?> !important;backbround-color:<?php echo e($web_config['primary_color']); ?>;width: <?php echo $widthRating = ($rating[4] != 0) ? ($rating[4] / $overallRating[1]) * 100 : (0); ?>%;"
                                                                        aria-valuenow="4" aria-valuemin="0" aria-valuemax="100"></div>
                                                                </div>
                                                            </div>
                                                            <div class="col-1">
                                                                <span
                                                                    class="<?php echo e(Session::get('direction') === "rtl" ? 'mr-3 float-left' : 'ml-3 float-right'); ?>">
                                                                        <?php echo e($rating[4]); ?>

                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row pb-4 mb-3">
                                                    <div style="display: block;width:100%;text-align: center;background: #F3F4F5;border-radius: 5px;padding:5px;">
                                                        <span class="text-capitalize"><?php echo e(\App\CPU\translate('Product Review')); ?></span>
                                                    </div>
                                                </div>
                                                <div class="row pb-4">
                                                    <div class="col-12" id="product-review-list">
                                                        
                                                            
                                                        
                                                        <?php if(count($product->reviews)==0): ?>
                                                            <div class="card">
                                                                <div class="card-body">
                                                                    <h6 class="text-danger text-center"><?php echo e(\App\CPU\translate('product_review_not_available')); ?></h6>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>

                                                    </div>
                                                    <div class="col-12">
                                                        <div class="card-footer d-flex justify-content-center align-items-center">
                                                            <button class="btn" style="background: <?php echo e($web_config['primary_color']); ?>; color: #ffffff" onclick="load_review()"><?php echo e(\App\CPU\translate('view more')); ?></button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col-md-3 ">
                <div class="product-details-shipping-details">
                    <div class="shipping-details-bottom-border">
                        <div style="padding: 25px;">
                            <img class="<?php echo e(Session::get('direction') === "rtl" ? 'float-right ml-2' : 'mr-2'); ?>" style="height: 20px;width:20px;" src="<?php echo e(asset("public/assets/front-end/png/Payment.png")); ?>"
                                    alt="">
                            <span><?php echo e(\App\CPU\translate('Safe Payment')); ?></span>
                        </div>
                    </div>
                    <div  class="shipping-details-bottom-border">
                        <div style="padding: 25px;">
                            <img class="<?php echo e(Session::get('direction') === "rtl" ? 'float-right ml-2' : 'mr-2'); ?>" style="height: 20px;width:20px;"
                                src="<?php echo e(asset("public/assets/front-end/png/money.png")); ?>"
                                    alt="">
                            <span><?php echo e(\App\CPU\translate('7 Days Return Policy')); ?></span>
                        </div>
                    </div>
                    <div class="shipping-details-bottom-border">
                       <div style="padding: 25px;">
                            <img class="<?php echo e(Session::get('direction') === "rtl" ? 'float-right ml-2' : 'mr-2'); ?>"
                                style="height: 20px;width:20px;"
                                src="<?php echo e(asset("public/assets/front-end/png/Genuine.png")); ?>"
                                alt="">
                            <span><?php echo e(\App\CPU\translate('100% Authentic Products')); ?></span>
                       </div>
                    </div>
                </div>



















































































































































































                <?php ($more_product_from_seller = App\Model\Product::where('added_by',$product->added_by)->where('user_id',$product->user_id)->latest()->take(5)->get()); ?>
                <div style="padding: 25px;">
                    <div class="row d-flex justify-content-center">
                        <span style="text-align: center;font-weight: 700;
                        font-size: 16px;">
                            <?php echo e(\App\CPU\translate('More From The Store')); ?>

                        </span>
                    </div>
                </div>
                <div style="">

                    <?php $__currentLoopData = $more_product_from_seller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php echo $__env->make('web-views.partials.seller-products-product-details',['product'=>$item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>


        </div>
    </div>

    <!-- Product carousel (You may also like)-->
    <div class="container  mb-3 rtl" style="text-align: <?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>;">
        <div class="row flex-between">
            <div class="text-capitalize" style="font-weight: 700; font-size: 30px;<?php echo e(Session::get('direction') === "rtl" ? 'margin-right: 5px;' : 'margin-left: 5px;'); ?>">
                <span><?php echo e(\App\CPU\translate('similar_products')); ?></span>
            </div>

            <div class="view_all d-flex justify-content-center align-items-center">
                <div>
                    <?php ($category=json_decode($product['category_ids'])); ?>
                    <a class="text-capitalize view-all-text" style="color:<?php echo e($web_config['primary_color']); ?> !important;<?php echo e(Session::get('direction') === "rtl" ? 'margin-left:10px;' : 'margin-right: 8px;'); ?>"
                       href="<?php echo e(route('products',['id'=> $category[0]->id,'data_from'=>'category','page'=>1])); ?>"><?php echo e(\App\CPU\translate('view_all')); ?>

                       <i class="czi-arrow-<?php echo e(Session::get('direction') === "rtl" ? 'left-circle mr-1 ml-n1 mt-1 ' : 'right-circle ml-1 mr-n1'); ?>"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- Grid-->

        <!-- Product-->
        <div class="row mt-4">
            <?php if(count($relatedProducts)>0): ?>
                <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $relatedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-2 col-sm-3 col-6" style="margin-bottom: 20px;">
                        <?php echo $__env->make('web-views.partials._single-product',['product'=>$relatedProduct], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="text-danger text-center"><?php echo e(\App\CPU\translate('similar')); ?> <?php echo e(\App\CPU\translate('product_not_available')); ?></h6>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="modal fade rtl" id="show-modal-view" tabindex="-1" role="dialog" aria-labelledby="show-modal-image"
         aria-hidden="true" style="text-align: <?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>;">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body" style="display: flex;justify-content: center">
                    <button class="btn btn-default"
                            style="border-radius: 50%;margin-top: -25px;position: absolute;<?php echo e(Session::get('direction') === "rtl" ? 'left' : 'right'); ?>: -7px;"
                            data-dismiss="modal">
                        <i class="fa fa-close"></i>
                    </button>
                    <img class="element-center" id="attachment-view" src="">
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

    <script type="text/javascript">
        cartQuantityInitialize();
        getVariantPrice();
        $('#add-to-cart-form input').on('change', function () {
            getVariantPrice();
        });

        function showInstaImage(link) {
            $("#attachment-view").attr("src", link);
            $('#show-modal-view').modal('toggle')
        }
    </script>
    <script>
        $( document ).ready(function() {
            load_review();
        });
        let load_review_count = 1;
        function load_review()
        {

            $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                    }
                });
            $.ajax({
                    type: "post",
                    url: '<?php echo e(route('review-list-product')); ?>',
                    data:{
                        product_id:<?php echo e($product->id); ?>,
                        offset:load_review_count
                    },
                    success: function (data) {
                        $('#product-review-list').append(data.productReview)
                        if(data.not_empty == 0 && load_review_count>2){
                            toastr.info('<?php echo e(\App\CPU\translate('no more review remain to load')); ?>', {
                                CloseButton: true,
                                ProgressBar: true
                            });
                            console.log('iff');
                        }
                    }
                });
                load_review_count++
        }
    </script>

    
    <script>
        $('#contact-seller').on('click', function (e) {
            // $('#seller_details').css('height', '200px');
            $('#seller_details').animate({'height': '276px'});
            $('#msg-option').css('display', 'block');
        });
        $('#sendBtn').on('click', function (e) {
            e.preventDefault();
            let msgValue = $('#msg-option').find('textarea').val();
            let data = {
                message: msgValue,
                shop_id: $('#msg-option').find('textarea').attr('shop-id'),
                seller_id: $('.msg-option').find('.seller_id').attr('seller-id'),
            }
            if (msgValue != '') {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                    }
                });

                $.ajax({
                    type: "post",
                    url: '<?php echo e(route('messages_store')); ?>',
                    data: data,
                    success: function (respons) {
                        console.log('send successfully');
                    }
                });
                $('#chatInputBox').val('');
                $('#msg-option').css('display', 'none');
                $('#contact-seller').find('.contact').attr('disabled', '');
                $('#seller_details').animate({'height': '125px'});
                $('#go_to_chatbox').css('display', 'block');
            } else {
                console.log('say something');
            }
        });
        $('#cancelBtn').on('click', function (e) {
            e.preventDefault();
            $('#seller_details').animate({'height': '114px'});
            $('#msg-option').css('display', 'none');
        });
    </script>

    <script type="text/javascript"
            src="https://platform-api.sharethis.com/js/sharethis.js#property=5f55f75bde227f0012147049&product=sticky-share-buttons"
            async="async"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.front-end.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/ikaedigital.com/click.ikaedigital.com/resources/views/web-views/products/details.blade.php ENDPATH**/ ?>